package br.com.fiap.insights.insights;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InsightsApplicationTests {

	@Test
	void contextLoads() {
	}

}
